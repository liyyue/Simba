export LD_LIBRARY_PATH=/data/simba/Simba_Spark_ODBC_Linux_Desktop/simba/spark/lib/64:$LD_LIBRARY_PATH
export ODBCINI=/data/simba/Simba_Spark_ODBC_Linux_Desktop/simba/spark/Setup/odbc.ini
export ODBCSYSINI=/data/simba/Simba_Spark_ODBC_Linux_Desktop/simba/spark/Setup
export SIMBASPARKINI=/data/simba/Simba_Spark_ODBC_Linux_Desktop/simba/spark/lib/64/simba.sparkodbc.ini
