export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib
export ODBCINI=/data/simba/Simba_Hive_ODBC_RedHat_CentOS/odbc.ini
export ODBCSYSINI=/data/simba/Simba_Hive_ODBC_RedHat_CentOS/odbcinst.ini
export SIMBAHIVEINI=/data/simba/Simba_Hive_ODBC_RedHat_CentOS/simba.hiveodbc.ini
