import java.sql.Connection; 
import java.sql.SQLException; 
import com.simba.hive.jdbc41.HS2DataSource;   
public class HiveJDBCUtil {  	
    public static String DRIVER_CLASS = "com.simba.hive.jdbc41.HS2Driver"; 
    public static String CONNECTION_URL = "jdbc:hive2://hdperf029.svl.ibm.com:10000/default;UID=hive;LogLevel=6;LogPath=simbalog";   
    public static Connection connectViaDS() {  		
        Connection connection = null; 		
        try { 			
            Class.forName(DRIVER_CLASS); 		
        } catch (ClassNotFoundException e) { 		
            e.printStackTrace(); 		
        } 		
        HS2DataSource ds = new com.simba.hive.jdbc41.HS2DataSource();
        ds.setURL(CONNECTION_URL); 		
        try { 			
            connection = ds.getConnection(); 		
        } catch (SQLException e) { 			
            e.printStackTrace(); 		
        } 		
        return connection; 	
    } 	 
}
