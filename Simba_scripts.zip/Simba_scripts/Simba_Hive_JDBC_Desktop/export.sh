export HIVEJDBC=/data/simba/Simba_Hive_JDBC_Desktop/Simba_Hive_JDBC_Desktop/Simba_HiveJDBC41_1.0.39.1050
export CLASSPATH=$CLASSPATH:.:$HIVEJDBC:$HIVEJDBC/HiveJDBC41.jar:$HIVEJDBC/TCLIServiceClient.jar:$HIVEJDBC/commons-codec-1.3.jar:$HIVEJDBC/commons-logging-1.1.1.jar:$HIVEJDBC/hive_metastore.jar:$HIVEJDBC/hive_service.jar:$HIVEJDBC/httpclient-4.1.3.jar:$HIVEJDBC/httpcore-4.1.3.jar:$HIVEJDBC/libfb303-0.9.0.jar:$HIVEJDBC/libthrift-0.9.0.jar:$HIVEJDBC/log4j-1.2.14.jar:$HIVEJDBC/ql.jar:$HIVEJDBC/slf4j-api-1.5.11.jar:$HIVEJDBC/slf4j-log4j12-1.5.11.jar:$HIVEJDBC/zookeeper-3.4.6.jar

