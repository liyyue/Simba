import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.Statement; 
 
public class HiveDataTypeTest {  	
    public static void main(String[] args) { 		
        Connection con = null; 		
        Statement stmt = null; 		
        ResultSet res = null; 		
        try { 			
            con = HiveJDBCUtil.connectViaDS(); 			
            stmt = con.createStatement(); 			
            String tableName = "testcol"; 		 			
            String sql = "select * from " + tableName;
            String sql_insert = "insert into " + tableName +" values (3,1,6464,TRUE,'aa','2017-05-05' ,6.1,7.1,8.1,9.1,10,11,'12','2011-12-07 13:01:03',14,'15') ";
            String sql_update = "update " + tableName +" set c1=2,c2='7474',c3=FALSE,c4='ss',c5='2016-05-05',c6=6.2,c7=7.2,c8=8.2,c9=9.2,c10=20,c11=21,c12='new12',c13='2011-12-07 13:01:03',c14=24,c15='25' ";
            String sql_delete = "delete from "+ tableName + " where c0=1";
            stmt.executeUpdate(sql_insert);
            stmt.executeUpdate(sql_update);
            stmt.executeUpdate(sql_delete);
            res = stmt.executeQuery(sql); 			
            while (res.next()) { 				
            System.out.println(String.valueOf(res.getInt(1)) + "\t" + String.valueOf(res.getInt(2)) + "\t" + String.valueOf(res.getString(3))+ "\t" + String.valueOf(res.getString(4))+ "\t" + String.valueOf(res.getString(5))+ "\t" + String.valueOf(res.getString(6))+ "\t" + String.valueOf(res.getDouble(7))+ "\t" + String.valueOf(res.getString(8))+ "\t" + String.valueOf(res.getString(9))+ "\t" + String.valueOf(res.getString(10))+ "\t" + String.valueOf(res.getInt(11))+ "\t" + String.valueOf(res.getInt(12))+ "\t" + String.valueOf(res.getString(13))+ "\t" + String.valueOf(res.getTimestamp(14))+ "\t" + String.valueOf(res.getInt(15))+ "\t" + String.valueOf(res.getString(16))); 			} 		
        } catch (Exception e) { 			
            e.printStackTrace(); 
        } finally { 			
            try { 				
                if (res != null) 					
                    res.close(); 				
                if (stmt != null) 					
                    stmt.close(); 			
                if (con != null) 					
                    con.close(); 			
            } catch (Exception e) { 				
                e.printStackTrace();  			
            } 		
        }  	
    }  
} 

