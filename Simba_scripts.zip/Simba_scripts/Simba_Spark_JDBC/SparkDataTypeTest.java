import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.Statement; 
 
public class SparkDataTypeTest {  	
    public static void main(String[] args) { 		
        Connection con = null; 		
        Statement stmt = null; 		
        ResultSet res = null; 		
        try { 			
            con = SparkJDBCUtil.connectViaDS(); 			
            stmt = con.createStatement(); 			
            //String tableName = "TEST_SIMBA_Spark"; 		 			
	    String tableName = "testsparkcol";
            String sql = "select * from " + tableName; 		
	    //String sql = "select count(*), 'aa' from " + tableName;
            res = stmt.executeQuery(sql); 			
            while (res.next()) { 				
            System.out.println(String.valueOf(res.getInt(1)) + "\t" + String.valueOf(res.getInt(2)) + "\t" + String.valueOf(res.getString(3))+ "\t" + String.valueOf(res.getString(4))+ "\t" + String.valueOf(res.getString(5))+ "\t" + String.valueOf(res.getString(6))+ "\t" + String.valueOf(res.getDouble(7))+ "\t" + String.valueOf(res.getString(8))+ "\t" + String.valueOf(res.getString(9))+ "\t" + String.valueOf(res.getString(10))+ "\t" + String.valueOf(res.getInt(11))+ "\t" + String.valueOf(res.getInt(12))+ "\t" + String.valueOf(res.getString(13))+ "\t" + String.valueOf(res.getTimestamp(14))+ "\t" + String.valueOf(res.getInt(15))+ "\t" + String.valueOf(res.getString(16))); 			} 			
        } catch (Exception e) { 			
            e.printStackTrace(); 
        } finally { 			
            try { 				
                if (res != null) 					
                    res.close(); 				
                if (stmt != null) 					
                    stmt.close(); 			
                if (con != null) 					
                    con.close(); 			
            } catch (Exception e) { 				
                e.printStackTrace();  			
            } 		
        }  	
    }  
} 

