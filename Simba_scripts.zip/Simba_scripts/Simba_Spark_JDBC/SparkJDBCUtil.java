import java.sql.Connection; 
import java.sql.SQLException; 
import com.simba.spark.jdbc41.DataSource;  
 
public class SparkJDBCUtil {  	
public static String DRIVER_CLASS = "com.simba.spark.jdbc41.Driver"; 	
public static String CONNECTION_URL = "jdbc:spark://hdperf028.svl.ibm.com:10016;UID=hive;LogLevel=6;LogPath=simbalogs";  	
//public static String CONNECTION_URL = "jdbc:spark://hdperf028.svl.ibm.com:10016/test_02;UID=hive;LogLevel=6;LogPath=simbalogs";
public static Connection connectViaDS() throws Exception {  		
Connection connection = null; 					
Class.forName(DRIVER_CLASS); 				
DataSource ds = new com.simba.spark.jdbc41.DataSource();  
ds.setURL(CONNECTION_URL); 				
connection = ds.getConnection(); 		 		
return connection;  	
} 	 
}

